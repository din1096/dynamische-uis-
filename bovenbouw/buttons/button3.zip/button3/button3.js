var totalbuttons = 30;
var totalrows = 5;
const container = document.getElementById('container');
const colours = ['red', 'purple', 'blue', 'black'];

for (var a = 0; a < totalbuttons; a++) {
    var button = document.createElement('button');
    button.innerHTML = a + 1;
    button.className = 'btn';
    let clickCount = 0;

    button.addEventListener('click', function() {
        clickCount++;
        this.style.backgroundColor = colours[clickCount % colours.length];
        if (clickCount === 5) {
            this.remove();
        }
    });

    container.appendChild(button);
}